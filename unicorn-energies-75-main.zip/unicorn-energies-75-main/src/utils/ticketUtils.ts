
// This file is kept for backward compatibility
// New code should import from src/utils/ticket directly
export * from './ticket';

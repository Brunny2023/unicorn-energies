
// Type guards to help with TypeScript type safety

/**
 * Checks if a value is defined (not null and not undefined)
 */
export function isDefined<T>(value: T | null | undefined): value is T {
  return value !== null && value !== undefined;
}

/**
 * Checks if a value is a valid number
 */
export function isValidNumber(value: any): value is number {
  return typeof value === 'number' && !isNaN(value) && isFinite(value);
}

/**
 * Safely converts a value to a number with a default value
 */
export function safeNumber(value: any, defaultValue: number = 0): number {
  if (value === null || value === undefined || value === '') {
    return defaultValue;
  }
  
  const num = Number(value);
  return isValidNumber(num) ? num : defaultValue;
}

/**
 * Safely converts a value to a string with a default value
 */
export function safeString(value: any, defaultValue: string = ''): string {
  if (value === null || value === undefined) {
    return defaultValue;
  }
  return String(value);
}

/**
 * Checks if a value is a non-null object
 */
export function isNonNullObject(value: any): value is Record<string, any> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

/**
 * Alias for isNonNullObject for backward compatibility
 */
export function isValidObject(value: any): value is Record<string, any> {
  return isNonNullObject(value);
}

/**
 * Checks if a value is a non-nullable type
 */
export function isNonNullable<T>(value: T | null | undefined): value is T {
  return value !== null && value !== undefined;
}

/**
 * Safely accesses a property from an object with type safety
 */
export function safeObjectProperty<T, K extends keyof T>(
  obj: T | null | undefined, 
  key: K, 
  defaultValue: T[K]
): T[K] {
  if (!obj) return defaultValue;
  return (obj[key] !== undefined && obj[key] !== null) ? obj[key] : defaultValue;
}

/**
 * Type guard to check if an object has a specific property
 */
export function hasProperty<K extends string>(obj: unknown, prop: K): obj is { [key in K]: unknown } {
  return isNonNullObject(obj) && prop in obj;
}

/**
 * Safely cast a value to a query value for Supabase
 */
export function asSafeQueryValue<T>(value: T): T {
  return value as unknown as T;
}

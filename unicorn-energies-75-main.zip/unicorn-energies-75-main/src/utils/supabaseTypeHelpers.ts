
import { Database } from "@/integrations/supabase/types";
import { AdminUser } from "@/types/admin";
import { Transaction } from "@/hooks/useTransactions";
import { isQueryError, SelectQueryError } from "@/integrations/supabase/client";
import { isNonNullObject } from "./typeGuards";

// Safe filter constants for Supabase queries to avoid type issues
export const SafeFilters = {
  transactions: {
    type: {
      withdrawal: "withdrawal" as const,
      deposit: "deposit" as const,
      investment: "investment" as const,
      fee: "fee" as const,
      profit: "profit" as const,
      credit: "credit" as const
    },
    status: {
      completed: "completed" as const,
      pending: "pending" as const,
      rejected: "rejected" as const,
      failed: "failed" as const
    }
  },
  investments: {
    status: {
      active: "active" as const,
      completed: "completed" as const,
      cancelled: "cancelled" as const
    }
  }
};

// Safe type cast for admin user objects
export function asAdminUser(data: any): AdminUser[] {
  if (!data || !Array.isArray(data)) {
    return [];
  }

  return data
    .filter(user => isNonNullObject(user) && 'id' in user && 'email' in user)
    .map(user => ({
      id: user.id || '',
      email: user.email || '',
      full_name: user.full_name || '',
      role: user.role || 'user',
      created_at: user.created_at || new Date().toISOString(),
      last_sign_in: user.last_sign_in || null
    }));
}

// Type-safe equals filter for Supabase queries
export function equalsFilter<T>(value: T): T {
  return value as T;
}

// Type-safe in filter for Supabase queries
export function inFilter<T>(values: T[]): T[] {
  return values as T[];
}

// Safe transaction data access
export function safeTransactionData(data: any): Transaction {
  if (!isNonNullObject(data)) {
    // Return default transaction data if input is invalid
    return {
      id: '',
      amount: 0,
      type: '',
      status: '',
      description: '',
      created_at: new Date().toISOString(),
      user_id: ''
    };
  }

  return {
    id: data.id || '',
    amount: typeof data.amount === 'number' ? data.amount : 0,
    type: data.type || '',
    status: data.status || '',
    description: data.description || '',
    created_at: data.created_at || new Date().toISOString(),
    user_id: data.user_id || '',
    created_by: data.created_by || null,
    metadata: data.metadata || null,
    updated_at: data.updated_at || null
  };
}

// Safely cast string ID to string for Supabase queries
export function asSafeId(id: string): string {
  return id as unknown as string;
}

// Cast operation that adds strong typing to Supabase query responses
export function asTypedArray<T>(data: any, defaultValue: T[]): T[] {
  if (!data || !Array.isArray(data)) {
    return defaultValue;
  }
  return data as unknown as T[];
}


// Development mode flag - set to false for production
export const DEVELOPMENT_MODE = false;


import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { aiTicketService, AI_ASSISTANT_NAME } from '@/utils/ticket/aiTicketService';
import AIStatsPanel from './ai-manager/AIStatsPanel';
import AIActivityPanel from './ai-manager/AIActivityPanel';
import AIStatusPanel from './ai-manager/AIStatusPanel';

interface RecentActivity {
  id: string;
  subject: string;
  status: string;
  responded_at: string;
}

const AIAdminManager = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [stats, setStats] = useState({
    total: 0,
    aiResponded: 0,
    open: 0,
    lastProcessed: null as string | null,
  });
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    setLoading(true);
    try {
      // Get total tickets
      const { data: totalData, error: totalError } = await supabase
        .from('tickets')
        .select('count', { count: 'exact' });
      
      if (totalError) throw totalError;
      
      // Get AI responded tickets
      const { data: aiData, error: aiError } = await supabase
        .from('tickets')
        .select('count', { count: 'exact' })
        .not('ai_response', 'is', null);
      
      if (aiError) throw aiError;
      
      // Get open tickets
      const { data: openData, error: openError } = await supabase
        .from('tickets')
        .select('count', { count: 'exact' })
        .eq('status', 'open' as any);
      
      if (openError) throw openError;
      
      // Get latest AI responded tickets
      const { data: recentData, error: recentError } = await supabase
        .from('tickets')
        .select('id, subject, status, ai_responded_at')
        .not('ai_response', 'is', null)
        .order('ai_responded_at', { ascending: false })
        .limit(5);
      
      if (recentError) throw recentError;

      // Check if data exists and handle it safely
      const totalCount = Array.isArray(totalData) && totalData.length > 0 && totalData[0] && 
        typeof totalData[0] === 'object' && 'count' in totalData[0] ? 
        Number(totalData[0].count) || 0 : 0;
      
      const aiCount = Array.isArray(aiData) && aiData.length > 0 && aiData[0] && 
        typeof aiData[0] === 'object' && 'count' in aiData[0] ? 
        Number(aiData[0].count) || 0 : 0;
      
      const openCount = Array.isArray(openData) && openData.length > 0 && openData[0] && 
        typeof openData[0] === 'object' && 'count' in openData[0] ? 
        Number(openData[0].count) || 0 : 0;

      // Safely get the latest response date
      let lastProcessedDate = null;
      if (Array.isArray(recentData) && recentData.length > 0 && recentData[0] && 
          typeof recentData[0] === 'object' && 'ai_responded_at' in recentData[0]) {
        lastProcessedDate = String(recentData[0].ai_responded_at);
      }

      setStats({
        total: totalCount,
        aiResponded: aiCount,
        open: openCount,
        lastProcessed: lastProcessedDate,
      });
      
      // Safely map AI responded tickets
      const formattedRecentData: RecentActivity[] = [];
      
      if (Array.isArray(recentData)) {
        for (const ticket of recentData) {
          if (ticket && typeof ticket === 'object') {
            const id = 'id' in ticket ? String(ticket.id) : '';
            const subject = 'subject' in ticket ? String(ticket.subject) : '';
            const status = 'status' in ticket ? String(ticket.status) : '';
            const responded_at = 'ai_responded_at' in ticket ? String(ticket.ai_responded_at) : '';
            
            formattedRecentData.push({
              id,
              subject,
              status,
              responded_at
            });
          }
        }
      }
      
      setRecentActivity(formattedRecentData);
    } catch (error) {
      console.error('Error fetching AI stats:', error);
      toast({
        title: 'Error',
        description: 'Failed to load AI assistant statistics',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const processOpenTickets = async () => {
    setProcessing(true);
    toast({
      title: 'Processing tickets',
      description: `${AI_ASSISTANT_NAME} is analyzing open tickets...`,
    });
    
    try {
      const result = await aiTicketService.processOpenTickets();
      
      toast({
        title: 'Processing complete',
        description: `Processed ${result.processed} tickets: ${result.successful} successful, ${result.failed} failed.`,
        variant: 'default',
      });
      
      // Refresh stats after processing
      await fetchStats();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to process open tickets',
        variant: 'destructive',
      });
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1">
        <AIStatusPanel 
          stats={stats}
          loading={loading}
          processing={processing}
          onProcess={processOpenTickets}
          onRefresh={fetchStats}
        />
      </div>
      
      <div className="lg:col-span-2">
        <AIActivityPanel 
          recentActivity={recentActivity}
          loading={loading}
        />
      </div>
    </div>
  );
};

export default AIAdminManager;


import React from "react";
import DashboardOverview from "./DashboardOverview";
import DashboardTopNav from "../layout/DashboardTopNav";
import { useTransactions } from "@/hooks/useTransactions";
import { useAuth } from "@/contexts/AuthContext";
import WalletSection from "./sections/WalletSection";
import PortfolioSection from "./sections/PortfolioSection";
import ActivitySection from "./sections/ActivitySection";
import { useDashboardData } from "./hooks/useDashboardData";

const DashboardContent = () => {
  const { user } = useAuth();
  const { transactions, loading: transactionsLoading } = useTransactions(user?.id || '');
  const { loading, walletData, investmentStats, ticketStats } = useDashboardData();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Dashboard Overview</h1>
        <p className="text-gray-400">Welcome to your investment dashboard</p>
      </div>
      
      {/* Dashboard navigation tabs */}
      <DashboardTopNav />
      
      {/* Stats and overview cards */}
      <WalletSection 
        loading={loading}
        walletData={walletData}
        investmentStats={investmentStats}
        ticketStats={ticketStats}
      />
      
      {/* Main dashboard content */}
      <PortfolioSection 
        loading={loading}
        investmentStats={investmentStats}
      />
      
      <ActivitySection 
        loading={loading || transactionsLoading}
        transactions={transactions}
      />
      
      <DashboardOverview />
    </div>
  );
};

export default DashboardContent;

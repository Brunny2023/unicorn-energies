
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useWalletData, WalletData } from "./useWalletData";
import { useInvestmentStats, InvestmentStats } from "./useInvestmentStats";
import { useTicketStats, TicketStats } from "./useTicketStats";

export const useDashboardData = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  
  const { walletData, loading: walletLoading } = useWalletData(user?.id);
  const { investmentStats, loading: investmentsLoading } = useInvestmentStats(user?.id);
  const { ticketStats, loading: ticketsLoading } = useTicketStats(user?.id);

  useEffect(() => {
    // If all data fetching is complete, set overall loading to false
    if (!walletLoading && !investmentsLoading && !ticketsLoading) {
      setLoading(false);
    } else {
      setLoading(true);
    }
  }, [walletLoading, investmentsLoading, ticketsLoading]);

  useEffect(() => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to view your dashboard data",
        variant: "destructive"
      });
    }
  }, [user, toast]);

  return {
    loading,
    walletData,
    investmentStats,
    ticketStats
  };
};


import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { isNonNullObject, safeNumber } from "@/utils/typeGuards";

export interface WalletData {
  balance: number;
  accrued_profits: number;
}

export const useWalletData = (userId: string | undefined) => {
  const { toast } = useToast();
  const [walletData, setWalletData] = useState<WalletData>({
    balance: 0,
    accrued_profits: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWalletData = async () => {
      if (!userId) {
        setLoading(false);
        return;
      }

      try {
        // Try to fetch wallet data from Supabase
        try {
          const { data, error } = await supabase
            .from('wallets')
            .select('*')
            .eq('user_id', userId)
            .single();
            
          if (error) {
            console.error("Error fetching wallet data:", error);
            // Use placeholder data if fetch fails
            setWalletData({
              balance: 5000,
              accrued_profits: 250
            });
          } else if (isNonNullObject(data)) {
            // Safely extract wallet data with null checks
            const balance = ('balance' in data)
              ? safeNumber(data.balance, 0) 
              : 0;
              
            const accruedProfits = ('accrued_profits' in data)
              ? safeNumber(data.accrued_profits, 0) 
              : 0;
            
            setWalletData({
              balance,
              accrued_profits: accruedProfits
            });
          }
        } catch (e) {
          console.error("Error in wallet data fetch:", e);
          // Use placeholder data
          setWalletData({
            balance: 5000,
            accrued_profits: 250
          });
        }
      } catch (error) {
        console.error("Error fetching wallet data:", error);
        toast({
          title: "Error",
          description: "Failed to load wallet data",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchWalletData();
  }, [userId, toast]);

  return { walletData, loading };
};

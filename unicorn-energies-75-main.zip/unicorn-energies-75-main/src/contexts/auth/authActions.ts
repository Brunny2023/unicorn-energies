
import { AuthToast, NavigateFunction } from "./types";
import { signIn } from "./actions/signinAction";
import { signUp } from "./actions/signupAction";
import { signOut } from "./actions/signoutAction";
import { checkIfAdmin, initializeSuperAdmin } from "./actions/adminAction";
import { forgotPassword, resetPassword, updatePassword } from "./actions/passwordActions";

export const authActions = {
  signIn,
  signUp,
  signOut,
  forgotPassword,
  resetPassword,
  updatePassword,
  checkIfAdmin,
  initializeSuperAdmin
};

// Re-export the functions so they can be imported directly
export { signIn, signUp, signOut, forgotPassword, resetPassword, updatePassword, checkIfAdmin, initializeSuperAdmin };

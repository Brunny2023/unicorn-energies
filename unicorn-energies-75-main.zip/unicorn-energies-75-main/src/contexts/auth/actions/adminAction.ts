
import { supabase } from "@/integrations/supabase/client";
import { isNonNullObject } from "@/utils/typeGuards";
import { createSuperAdmin } from "@/utils/admin/createSuperAdmin";

/**
 * Check if a user is an admin
 * @param userId The user ID to check
 * @returns boolean
 */
export const checkIfAdmin = async (userId: string): Promise<boolean> => {
  if (!userId) {
    console.log("No user ID provided for admin check");
    return false;
  }
  
  try {
    console.log("Checking if user is admin:", userId);
    
    // First try using the built-in is_admin function if available
    try {
      const { data: isAdminResult, error: isAdminError } = await supabase.rpc('is_admin', {
        user_id: userId
      });
      
      if (!isAdminError && typeof isAdminResult === 'boolean') {
        console.log("Admin check using RPC function:", isAdminResult);
        return isAdminResult;
      }
    } catch (e) {
      console.error("Error using is_admin RPC function:", e);
      // Continue to fallback method
    }
    
    // Fallback: check user role in profiles table
    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', userId)
      .single();
      
    if (profileError) {
      console.error("Error checking for admin role:", profileError);
      return false;
    }
    
    if (isNonNullObject(profileData) && 'role' in profileData) {
      const isAdmin = profileData.role === 'admin';
      console.log("Admin check from profiles table:", isAdmin);
      return isAdmin;
    }
    
    return false;
  } catch (error) {
    console.error("Error checking for super admin:", error);
    return false;
  }
};

/**
 * Create an admin user
 */
export const createAdminUser = async (email: string, password: string, fullName: string): Promise<boolean> => {
  try {
    console.log("Creating admin user:", email);
    
    // Create new user with auth
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
        }
      }
    });
    
    if (error) {
      console.error("Error creating admin user:", error);
      return false;
    }
    
    if (data.user) {
      console.log("Admin user created:", data.user.id);
      
      // Update role to admin
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ role: 'admin' })
        .eq('id', data.user.id);
      
      if (profileError) {
        console.error("Error updating admin role:", profileError);
        return false;
      } else {
        console.log("Admin user role set successfully");
        return true;
      }
    }
    
    return false;
  } catch (error) {
    console.error("Error creating admin user:", error);
    return false;
  }
};

/**
 * Initialize super admin account
 */
export const initializeSuperAdmin = async (): Promise<void> => {
  try {
    console.log("Initializing super admin account");
    await createSuperAdmin();
  } catch (error) {
    console.error("Error initializing super admin:", error);
  }
};

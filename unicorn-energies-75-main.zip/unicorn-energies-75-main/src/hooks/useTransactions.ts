
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { equalsFilter } from "@/utils/supabaseTypeHelpers";
import { isNonNullObject, safeNumber, safeString, isValidObject } from "@/utils/typeGuards";

// Transaction data interface
export interface Transaction {
  id: string;
  amount: number;
  type: string;
  status: string;
  description: string;
  created_at: string;
  user_id: string;
  created_by?: string | null;
  metadata?: any | null;
  updated_at?: string | null;
}

// Safely convert any data to Transaction type
const convertToTransaction = (item: any): Transaction => {
  if (!isNonNullObject(item)) {
    return {
      id: '',
      amount: 0,
      type: '',
      status: '',
      description: '',
      created_at: new Date().toISOString(),
      user_id: ''
    };
  }

  return {
    id: safeString(item.id, ''),
    amount: safeNumber(item.amount, 0),
    type: safeString(item.type, ''),
    status: safeString(item.status, ''),
    description: safeString(item.description, ''),
    created_at: safeString(item.created_at, new Date().toISOString()),
    user_id: safeString(item.user_id, ''),
    created_by: item.created_by || null,
    metadata: item.metadata || null,
    updated_at: item.updated_at || null
  };
};

export const useTransactions = (userId?: string) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }

    const fetchTransactions = async () => {
      try {
        setLoading(true);
        console.log("Fetching transactions for user:", userId);
        
        // Try to fetch from Supabase first
        try {
          const { data, error } = await supabase
            .from('transactions')
            .select('*')
            .eq('user_id', userId as any)
            .order('created_at', { ascending: false });
            
          if (error) {
            console.error("Supabase error:", error);
            throw error;
          }
          
          if (data && data.length > 0) {
            console.log("Found transactions in Supabase:", data.length);
            // Safely convert to Transaction[] with proper type safety
            const safeTransactions = data.map(item => convertToTransaction(item));
            
            setTransactions(safeTransactions);
            setLoading(false);
            return;
          } else {
            console.log("No transactions found in Supabase, using mock data");
          }
        } catch (supabaseError) {
          console.error("Error fetching transactions from Supabase:", supabaseError);
          // Continue to use mock data if Supabase fetch fails
        }
        
        // If we reached here, use mock data
        console.log("Using mock transaction data for user:", userId);
        
        // Mock data
        const mockTransactions: Transaction[] = [
          {
            id: '1',
            amount: 1000,
            type: 'deposit',
            status: 'completed',
            description: 'Initial deposit',
            created_at: new Date().toISOString(),
            user_id: userId
          },
          {
            id: '2',
            amount: 250,
            type: 'withdrawal',
            status: 'pending',
            description: 'Withdrawal request',
            created_at: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
            user_id: userId
          },
          {
            id: '3',
            amount: 500,
            type: 'investment',
            status: 'completed',
            description: 'Gold investment plan',
            created_at: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
            user_id: userId
          },
          {
            id: '4',
            amount: 50,
            type: 'fee',
            status: 'completed',
            description: 'Platform fee',
            created_at: new Date(Date.now() - 259200000).toISOString(), // 3 days ago
            user_id: userId
          },
          {
            id: '5',
            amount: 100,
            type: 'profit',
            status: 'completed',
            description: 'Investment profit',
            created_at: new Date(Date.now() - 345600000).toISOString(), // 4 days ago
            user_id: userId
          }
        ];
        
        setTransactions(mockTransactions);
      } catch (err) {
        console.error("Error in useTransactions hook:", err);
        setError(err instanceof Error ? err : new Error('Unknown error occurred'));
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, [userId]);

  return { transactions, loading, error };
};

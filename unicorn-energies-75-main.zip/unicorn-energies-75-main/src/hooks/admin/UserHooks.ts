
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { AdminUser, UserWallet } from "@/types/admin";
import { isNonNullObject } from "@/utils/typeGuards";

/**
 * Hook for fetching wallet data for users
 */
export const useUserWallets = () => {
  const [userWallets, setUserWallets] = useState<Record<string, UserWallet>>({});
  const { toast } = useToast();

  const fetchWalletsForUsers = async (userIds: string[]) => {
    try {
      // Use a separate query to avoid the IN clause typing issues
      let walletsMap: Record<string, UserWallet> = {};
      
      // Fetch wallets one by one to avoid IN clause type errors
      for (const userId of userIds) {
        try {
          const { data, error } = await supabase
            .from("wallets")
            .select("id, user_id, balance")
            .eq("user_id", userId)
            .single();
            
          if (!error && isNonNullObject(data)) {
            const walletId = data.id ?? '';
            const walletBalance = typeof data.balance === 'number' ? data.balance : 0;
            
            walletsMap[userId] = { 
              id: walletId, 
              balance: walletBalance 
            };
          }
        } catch (e) {
          console.error(`Error fetching wallet for user ${userId}:`, e);
        }
      }
      
      setUserWallets(walletsMap);
      return walletsMap;
    } catch (error) {
      console.error("Error fetching wallets:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load user wallets. Please try again.",
      });
      return {};
    }
  };

  return {
    userWallets,
    fetchWalletsForUsers
  };
};

/**
 * Hook for updating user roles
 */
export const useRoleUpdater = () => {
  const [isUpdatingRole, setIsUpdatingRole] = useState(false);
  const { toast } = useToast();

  const updateUserRole = async (userId: string, selectedRole: string) => {
    if (!userId || !selectedRole || isUpdatingRole) return false;
    
    setIsUpdatingRole(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({ role: selectedRole })
        .eq("id", userId);

      if (error) throw error;
      
      toast({
        title: "Role updated",
        description: `User's role has been updated to ${selectedRole}`,
      });
      
      setIsUpdatingRole(false);
      return true;
    } catch (error) {
      console.error("Error updating role:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update user role. Please try again.",
      });
      setIsUpdatingRole(false);
      return false;
    }
  };

  return {
    isUpdatingRole,
    updateUserRole
  };
};

/**
 * Hook for crediting users
 */
export const useCreditUser = (currentUserId: string | undefined) => {
  const [isProcessingCredit, setIsProcessingCredit] = useState(false);
  const { toast } = useToast();

  const creditUserWallet = async (
    userId: string, 
    amount: number, 
    walletId: string, 
    currentBalance: number
  ) => {
    if (!userId || isNaN(amount) || amount <= 0 || isProcessingCredit) return false;
    
    setIsProcessingCredit(true);
    try {
      // Update wallet balance
      const { error: walletError } = await supabase
        .from("wallets")
        .update({ 
          balance: currentBalance + amount,
          updated_at: new Date().toISOString()
        })
        .eq("id", walletId);

      if (walletError) throw walletError;
      
      // Create transaction record
      const { error: transactionError } = await supabase
        .from("transactions")
        .insert({
          user_id: userId,
          amount,
          type: "credit",
          status: "completed",
          description: "Admin credit",
          created_by: currentUserId
        });

      if (transactionError) throw transactionError;
      
      toast({
        title: "Credit successful",
        description: `$${amount.toFixed(2)} has been credited to the user's account`,
      });
      
      setIsProcessingCredit(false);
      return true;
    } catch (error) {
      console.error("Error crediting user:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to credit user. Please try again.",
      });
      setIsProcessingCredit(false);
      return false;
    }
  };

  return {
    isProcessingCredit,
    creditUserWallet
  };
};


// Re-export all ticket hooks from the new location
// This file is maintained for backward compatibility
export * from './tickets';

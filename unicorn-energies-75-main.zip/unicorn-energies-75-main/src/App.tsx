
import React, { useEffect } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from "@/components/ui/toaster"
import { AuthProvider } from './contexts/AuthContext'
import { setupConsoleFilters } from './utils/consoleErrorFilter'
import { authActions } from './contexts/auth/authActions'

// Public pages
import Index from "@/pages/Index"
import About from "@/pages/About"
import InvestmentPlans from "@/pages/InvestmentPlans"
import Calculator from "@/pages/Calculator"
import Contact from "@/pages/Contact"
import Faq from "@/pages/Faq"
import HowItWorks from "@/pages/HowItWorks"
import Terms from "@/pages/Terms"
import Privacy from "@/pages/Privacy"

// Auth pages
import Login from "@/pages/auth/Login"
import Register from "@/pages/auth/Register"
import ForgotPassword from "@/pages/auth/ForgotPassword"
import ResetPassword from "@/pages/auth/ResetPassword"
import AdminLogin from "@/pages/auth/AdminLogin"

// Dashboard pages
import Dashboard from "@/pages/dashboard/Dashboard"
import Investments from "@/pages/dashboard/Investments"
import Transactions from "@/pages/dashboard/Transactions"
import Withdraw from "@/pages/dashboard/Withdraw"
import Deposit from "@/pages/dashboard/Deposit"
import Loans from "@/pages/dashboard/Loans"
import Affiliates from "@/pages/dashboard/Affiliates"
import Settings from "@/pages/dashboard/Settings"
import TicketsIndex from "@/pages/dashboard/tickets/TicketsIndex"
import NewTicket from "@/pages/dashboard/tickets/NewTicket"
import TicketView from "@/pages/dashboard/tickets/TicketView"

// Admin pages
import AdminDashboard from "@/pages/admin/Dashboard"
import AdminUsers from "@/pages/admin/Users"
import AdminTransactions from "@/pages/admin/Transactions"
import AdminTickets from "@/pages/admin/Tickets"
import AdminTicketDetails from "@/pages/admin/TicketDetails"
import AdminPaymentConnections from "@/pages/admin/PaymentConnections"
import AdminBroadcastMessages from "@/pages/admin/BroadcastMessages"
import AdminSettings from "@/pages/admin/Settings"
import EmailTemplateEditor from "@/pages/admin/EmailTemplateEditor"

// Auth Guards
import ProtectedRoute from "@/components/auth/ProtectedRoute"
import AdminRoute from "@/components/auth/AdminRoute"

function App() {
  useEffect(() => {
    setupConsoleFilters();
    
    // Initialize super admin account
    try {
      console.log("Initializing super admin account");
      authActions.initializeSuperAdmin();
    } catch (error) {
      console.error("Error initializing super admin:", error);
    }
  }, []);

  return (
    <AuthProvider>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Index />} />
        <Route path="/about" element={<About />} />
        <Route path="/investment-plans" element={<InvestmentPlans />} />
        <Route path="/calculator" element={<Calculator />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/faq" element={<Faq />} />
        <Route path="/how-it-works" element={<HowItWorks />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/privacy" element={<Privacy />} />

        {/* Auth Routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/admin-login" element={<AdminLogin />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />

        {/* Protected Dashboard Routes */}
        <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/dashboard/*" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/investments" element={<ProtectedRoute><Investments /></ProtectedRoute>} />
        <Route path="/transactions" element={<ProtectedRoute><Transactions /></ProtectedRoute>} />
        <Route path="/deposit" element={<ProtectedRoute><Deposit /></ProtectedRoute>} />
        <Route path="/withdraw" element={<ProtectedRoute><Withdraw /></ProtectedRoute>} />
        <Route path="/loans" element={<ProtectedRoute><Loans /></ProtectedRoute>} />
        <Route path="/affiliates" element={<ProtectedRoute><Affiliates /></ProtectedRoute>} />
        <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
        <Route path="/tickets" element={<ProtectedRoute><TicketsIndex /></ProtectedRoute>} />
        <Route path="/tickets/new" element={<ProtectedRoute><NewTicket /></ProtectedRoute>} />
        <Route path="/tickets/:id" element={<ProtectedRoute><TicketView /></ProtectedRoute>} />

        {/* Admin Routes */}
        <Route path="/admin" element={<Navigate to="/admin/dashboard" replace />} />
        <Route path="/admin/dashboard" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
        <Route path="/admin/users" element={<AdminRoute><AdminUsers /></AdminRoute>} />
        <Route path="/admin/transactions" element={<AdminRoute><AdminTransactions /></AdminRoute>} />
        <Route path="/admin/tickets" element={<AdminRoute><AdminTickets /></AdminRoute>} />
        <Route path="/admin/tickets/:id" element={<AdminRoute><AdminTicketDetails /></AdminRoute>} />
        <Route path="/admin/payment-connections" element={<AdminRoute><AdminPaymentConnections /></AdminRoute>} />
        <Route path="/admin/broadcast" element={<AdminRoute><AdminBroadcastMessages /></AdminRoute>} />
        <Route path="/admin/settings" element={<AdminRoute><AdminSettings /></AdminRoute>} />
        <Route path="/admin/settings/email-templates/:templateId" element={<AdminRoute><EmailTemplateEditor /></AdminRoute>} />
        
        {/* Fallback Route */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <Toaster />
    </AuthProvider>
  )
}

export default App


import React, { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { AdminUser } from "@/types/admin";
import AdminLayout from "@/components/layout/AdminLayout";
import UserFilters from "@/components/admin/users/UserFilters";
import UsersTable from "@/components/admin/users/UsersTable";
import UserRoleDialog from "@/components/admin/users/UserRoleDialog";
import CreditUserDialog from "@/components/admin/users/CreditUserDialog";
import { useUserWallets, useRoleUpdater, useCreditUser } from "@/hooks/admin/UserHooks";
import { useUsersData } from "@/components/admin/users/hooks/useUsersData";

const Users = () => {
  const { user: currentUser } = useAuth();
  const { 
    filteredUsers, 
    searchTerm, 
    setSearchTerm, 
    loading, 
    fetchUsers 
  } = useUsersData();
  
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [roleDialogOpen, setRoleDialogOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState("");
  const [creditDialogOpen, setCreditDialogOpen] = useState(false);
  const [creditAmount, setCreditAmount] = useState("");
  
  // Custom hooks
  const { userWallets, fetchWalletsForUsers } = useUserWallets();
  const { isUpdatingRole, updateUserRole } = useRoleUpdater();
  const { isProcessingCredit, creditUserWallet } = useCreditUser(currentUser?.id);

  // Fetch wallet data when users are loaded
  React.useEffect(() => {
    if (filteredUsers.length > 0) {
      fetchWalletsForUsers(filteredUsers.map(u => u.id));
    }
  }, [filteredUsers]);

  const handleRoleUpdate = async () => {
    if (!selectedUser) return;
    
    const success = await updateUserRole(selectedUser.id, selectedRole);
    
    if (success) {
      await fetchUsers();
      setRoleDialogOpen(false);
    }
  };

  const handleCreditUser = async () => {
    if (!selectedUser || !creditAmount) return;
    
    const amount = parseFloat(creditAmount);
    if (isNaN(amount) || amount <= 0) {
      return;
    }
    
    const wallet = userWallets[selectedUser.id];
    
    if (!wallet) {
      return;
    }
    
    const success = await creditUserWallet(
      selectedUser.id, 
      amount, 
      wallet.id, 
      wallet.balance
    );
    
    if (success) {
      // Update local state with the new balance
      await fetchWalletsForUsers([selectedUser.id]);
      setCreditDialogOpen(false);
    }
  };

  const openRoleDialog = (user: AdminUser) => {
    setSelectedUser(user);
    setSelectedRole(user.role);
    setRoleDialogOpen(true);
  };

  const openCreditDialog = (user: AdminUser) => {
    setSelectedUser(user);
    setCreditAmount("");
    setCreditDialogOpen(true);
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <h2 className="text-3xl font-bold text-white">User Management</h2>
          <UserFilters 
            searchTerm={searchTerm} 
            onSearch={setSearchTerm} 
            onRefresh={fetchUsers} 
          />
        </div>

        <UsersTable 
          users={filteredUsers}
          userWallets={userWallets}
          loading={loading}
          onEditRole={openRoleDialog}
          onCreditUser={openCreditDialog}
        />
      </div>

      <UserRoleDialog 
        open={roleDialogOpen}
        onOpenChange={setRoleDialogOpen}
        selectedUser={selectedUser}
        selectedRole={selectedRole}
        onRoleChange={setSelectedRole}
        onSave={handleRoleUpdate}
        isLoading={isUpdatingRole}
      />

      <CreditUserDialog 
        open={creditDialogOpen}
        onOpenChange={setCreditDialogOpen}
        selectedUser={selectedUser}
        userWallets={userWallets}
        creditAmount={creditAmount}
        onCreditAmountChange={setCreditAmount}
        onConfirm={handleCreditUser}
        isLoading={isProcessingCredit}
      />
    </AdminLayout>
  );
};

export default Users;
